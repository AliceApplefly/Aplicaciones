# Fresenius Home - App Android

## Objetivo del Proyecto

Aplicación Android para el catálogo de productos de nutrición enteral de Fresenius, desarrollada con Jetpack Compose, MVVM, DataStore y Retrofit. La app incluye funcionalidades de login/registro, catálogo de productos, detalle de productos y carrito de compras local.

## Pantallas

- **SplashScreen**: Pantalla de carga que decide la navegación según el token guardado
- **LoginScreen**: Inicio de sesión con validaciones básicas
- **RegisterScreen**: Registro de nuevos usuarios
- **CatalogScreen**: Lista de productos con opciones de agregar al carrito
- **DetailScreen**: Detalle completo de un producto con controles de cantidad
- **CartScreen**: Carrito de compras con gestión local

## Estructura de Carpetas

```
com.aplicacion.freseniushome
├── Views/              // Composables de pantallas
│   ├── SplashScreen.kt
│   ├── LoginScreen.kt
│   ├── RegisterScreen.kt
│   ├── CatalogScreen.kt
│   ├── DetailScreen.kt
│   └── CartScreen.kt
├── ViewModel/          // ViewModels simples (sin DI)
│   ├── LoginViewModel.kt
│   ├── RegisterViewModel.kt
│   ├── CatalogViewModel.kt
│   └── CartViewModel.kt
├── model/              // Data classes
│   └── Usuario.kt
├── data/
│   ├── local/          // DataStore helpers
│   │   └── SessionPrefs.kt
│   └── remote/         // Retrofit
│       ├── ApiConfig.kt
│       ├── ApiServices.kt
│       └── RetrofitClient.kt
└── ui/theme/           // Tema Compose
    ├── Theme.kt
    └── Type.kt
```

## Configuración de la API

Para usar un backend real (como Xano), modifica la URL en `ApiConfig.kt`:

```kotlin
object ApiConfig {
    const val API_BASE = "https://tu-backend.com/api/"
}
```

## Cómo Ejecutar y Probar

1. **Clonar y abrir** el proyecto en Android Studio
2. **Sincronizar** las dependencias de Gradle
3. **Ejecutar** en un dispositivo o emulador
4. **Flujo de prueba**:
   - Registrarse con un nuevo usuario
   - Iniciar sesión
   - Explorar el catálogo de productos
   - Ver detalles de productos
   - Agregar productos al carrito
   - Gestionar el carrito
   - Cerrar sesión

## Tecnologías Utilizadas

- **Kotlin** - Lenguaje de programación
- **Jetpack Compose** - UI moderna y declarativa
- **Material3** - Sistema de diseño
- **MVVM** - Patrón de arquitectura
- **DataStore** - Persistencia de datos de sesión
- **Retrofit** - Cliente HTTP para APIs
- **Navigation Compose** - Navegación entre pantallas
- **Coroutines** - Programación asíncrona

## Rúbrica de Evaluación

El código incluye comentarios marcados con `// RUBRICA:` que indican los elementos evaluados:

- ✅ **Navegación**: SplashScreen con navegación condicional por sesión
- ✅ **MVVM**: ViewModels con estado y validaciones básicas
- ✅ **DataStore**: Persistencia de sesión con SessionPrefs
- ✅ **Consumo de API**: Servicios Retrofit para autenticación y productos
- ✅ **Carrito local**: Gestión de carrito en memoria con CartViewModel
- ✅ **Compose**: Listas y estado con Jetpack Compose
- ✅ **Argumentos**: Paso de argumentos con Navigation-Compose

## Funcionalidades Implementadas

### Autenticación
- Login con email y contraseña
- Registro de nuevos usuarios
- Validaciones básicas (email válido, contraseña ≥8 caracteres)
- Persistencia de sesión con DataStore
- Logout que limpia la sesión

### Catálogo de Productos
- Lista de productos desde API
- Manejo de estados de carga y error
- Cards con información básica (nombre, precio, stock)
- Botones para ver detalle y agregar al carrito

### Detalle de Producto
- Información completa del producto
- Controles de cantidad para el carrito
- Validación de stock disponible
- Navegación de regreso

### Carrito de Compras
- Gestión local en memoria (fase 1)
- Agregar/quitar productos
- Cálculo de total en CLP
- Vaciar carrito completo
- Interfaz intuitiva con badges de cantidad

## Próximas Mejoras

- Implementar checkout real con API
- Persistencia del carrito en DataStore
- Carga de imágenes con Coil
- Búsqueda y filtros en el catálogo
- Notificaciones push
- Modo offline con Room Database
