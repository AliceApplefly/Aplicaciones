package com.aplicacion.freseniushome.ViewModel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aplicacion.freseniushome.data.remote.RetrofitClient
import com.aplicacion.freseniushome.model.Producto
import kotlinx.coroutines.launch

class CatalogViewModel(application: Application) : AndroidViewModel(application) {
    
    var productos by mutableStateOf<List<Producto>>(emptyList())
        private set
    var isLoading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun cargarProductos() {
        isLoading = true
        error = null

        viewModelScope.launch {
            try {
                val response = RetrofitClient.products.listProducts()
                
                if (response.isSuccessful) {
                    productos = response.body() ?: emptyList()
                } else {
                    error = "Error al cargar productos: ${response.code()}"
                }
            } catch (e: Exception) {
                error = "Error de conexión: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    fun getProductoById(id: Int): Producto? {
        return productos.find { it.id == id }
    }
}
