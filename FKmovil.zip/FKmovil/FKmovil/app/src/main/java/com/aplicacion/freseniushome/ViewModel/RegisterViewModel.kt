package com.aplicacion.freseniushome.ViewModel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aplicacion.freseniushome.data.remote.RetrofitClient
import com.aplicacion.freseniushome.model.RegisterRequest
import kotlinx.coroutines.launch

class RegisterViewModel(application: Application) : AndroidViewModel(application) {
    
    var name by mutableStateOf("")
        private set
    var email by mutableStateOf("")
        private set
    var password by mutableStateOf("")
        private set
    var isLoading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set

    fun updateName(newName: String) {
        name = newName
        error = null
    }

    fun updateEmail(newEmail: String) {
        email = newEmail
        error = null
    }

    fun updatePassword(newPassword: String) {
        password = newPassword
        error = null
    }

    fun doRegister(onSuccess: () -> Unit) {
        if (name.isBlank()) {
            error = "El nombre es requerido"
            return
        }
        
        if (!isValidEmail(email)) {
            error = "Email inválido"
            return
        }
        
        if (password.length < 8) {
            error = "La contraseña debe tener al menos 8 caracteres"
            return
        }

        isLoading = true
        error = null

        viewModelScope.launch {
            try {
                val response = RetrofitClient.auth.register(
                    RegisterRequest(name, email, password)
                )
                
                if (response.isSuccessful) {
                    onSuccess()
                } else {
                    when (response.code()) {
                        400 -> error = "Email ya registrado o datos inválidos"
                        409 -> error = "El email ya está en uso"
                        else -> error = "Error del servidor: ${response.code()}"
                    }
                }
            } catch (e: Exception) {
                error = "Error de conexión: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return email.contains("@") && email.isNotBlank()
    }
}
