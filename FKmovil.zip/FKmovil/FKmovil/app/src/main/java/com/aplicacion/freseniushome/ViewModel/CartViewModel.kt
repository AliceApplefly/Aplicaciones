package com.aplicacion.freseniushome.ViewModel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.aplicacion.freseniushome.model.Producto

class CartViewModel(application: Application) : AndroidViewModel(application) {
    
    private val _items = mutableStateOf<Map<Int, Int>>(emptyMap())
    val items: Map<Int, Int> by _items

    fun add(productId: Int) {
        val currentItems = _items.value.toMutableMap()
        val currentQty = currentItems[productId] ?: 0
        currentItems[productId] = currentQty + 1
        _items.value = currentItems
    }

    fun remove(productId: Int) {
        val currentItems = _items.value.toMutableMap()
        val currentQty = currentItems[productId] ?: 0
        if (currentQty > 1) {
            currentItems[productId] = currentQty - 1
        } else {
            currentItems.remove(productId)
        }
        _items.value = currentItems
    }

    fun removeCompletely(productId: Int) {
        val currentItems = _items.value.toMutableMap()
        currentItems.remove(productId)
        _items.value = currentItems
    }

    fun clear() {
        _items.value = emptyMap()
    }

    fun getQuantity(productId: Int): Int {
        return items[productId] ?: 0
    }

    suspend fun totalClp(products: List<Producto>): Int {
        return items.entries.sumOf { (productId, quantity) ->
            val product = products.find { it.id == productId }
            (product?.price_clp ?: 0) * quantity
        }
    }

    fun getTotalItems(): Int {
        return items.values.sum()
    }
}
