package com.aplicacion.freseniushome.ViewModel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aplicacion.freseniushome.data.local.SessionPrefs
import com.aplicacion.freseniushome.data.remote.RetrofitClient
import com.aplicacion.freseniushome.model.LoginRequest
import com.aplicacion.freseniushome.model.Usuario
import kotlinx.coroutines.launch

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    
    private val sessionPrefs = SessionPrefs(application.applicationContext)
    
    var email by mutableStateOf("")
        private set
    var password by mutableStateOf("")
        private set
    var isLoading by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
        private set
    var user by mutableStateOf<Usuario?>(null)
        private set

    fun updateEmail(newEmail: String) {
        email = newEmail
    }

    fun updatePassword(newPassword: String) {
        password = newPassword
    }

    fun doLogin(onSuccess: () -> Unit) {
        if (!isValidEmail(email)) {
            error = "Email inválido"
            return
        }
        
        if (password.length < 8) {
            error = "La contraseña debe tener al menos 8 caracteres"
            return
        }

        isLoading = true
        error = null

        viewModelScope.launch {
            try {
                val response = RetrofitClient.auth.login(LoginRequest(email, password))
                
                if (response.isSuccessful) {
                    val authResponse = response.body()
                    if (authResponse != null) {
                        sessionPrefs.saveToken(authResponse.token, authResponse.user.email)
                        user = authResponse.user
                        
                        RetrofitClient.tokenProvider = { authResponse.token }
                        
                        onSuccess()
                    } else {
                        error = "Error en la respuesta del servidor"
                    }
                } else {
                    when (response.code()) {
                        401 -> error = "Credenciales inválidas"
                        400 -> error = "Datos incorrectos"
                        else -> error = "Error del servidor: ${response.code()}"
                    }
                }
            } catch (e: Exception) {
                error = "Error de conexión: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return email.contains("@") && email.isNotBlank()
    }
}
