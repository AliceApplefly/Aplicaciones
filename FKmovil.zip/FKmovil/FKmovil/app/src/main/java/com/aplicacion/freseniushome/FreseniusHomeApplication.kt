package com.aplicacion.freseniushome

import android.app.Application
import com.aplicacion.freseniushome.data.local.SessionPrefs
import com.aplicacion.freseniushome.data.remote.RetrofitClient

class FreseniusHomeApplication : Application() {
    
    lateinit var sessionPrefs: SessionPrefs
        private set

    override fun onCreate() {
        super.onCreate()
        
        sessionPrefs = SessionPrefs(this)
        
        RetrofitClient.tokenProvider = {
            null
        }
    }
}
