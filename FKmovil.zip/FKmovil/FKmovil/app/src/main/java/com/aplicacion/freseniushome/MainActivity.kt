package com.aplicacion.freseniushome

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.aplicacion.freseniushome.Views.*
import com.aplicacion.freseniushome.ViewModel.*
import com.aplicacion.freseniushome.ui.theme.FreseniusHomeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            FreseniusHomeTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    FreseniusHomeApp()
                }
            }
        }
    }
}

@Composable
fun FreseniusHomeApp() {
    val navController = rememberNavController()
    val application = androidx.compose.ui.platform.LocalContext.current.applicationContext as FreseniusHomeApplication
    
    val loginViewModel = remember { LoginViewModel(application) }
    val registerViewModel = remember { RegisterViewModel(application) }
    val catalogViewModel = remember { CatalogViewModel(application) }
    val cartViewModel = remember { CartViewModel(application) }

    NavHost(
        navController = navController,
        startDestination = "Splash"
    ) {
        composable("Splash") {
            SplashScreen(
                navController = navController,
                sessionPrefs = application.sessionPrefs
            )
        }
        
        composable("Login") {
            LoginScreen(
                navController = navController,
                viewModel = loginViewModel
            )
        }
        
        composable("Register") {
            RegisterScreen(
                navController = navController,
                viewModel = registerViewModel
            )
        }
        
        composable("Catalog") {
            CatalogScreen(
                navController = navController,
                catalogViewModel = catalogViewModel,
                cartViewModel = cartViewModel,
                sessionPrefs = application.sessionPrefs
            )
        }
        
        composable(
            "Detail/{productId}",
            arguments = listOf(
                navArgument("productId") { type = NavType.IntType }
            )
        ) { backStackEntry ->
            val productId = backStackEntry.arguments?.getInt("productId") ?: 0
            DetailScreen(
                navController = navController,
                productId = productId,
                catalogViewModel = catalogViewModel,
                cartViewModel = cartViewModel
            )
        }
        
        composable("Cart") {
            CartScreen(
                navController = navController,
                cartViewModel = cartViewModel,
                catalogViewModel = catalogViewModel
            )
        }
    }
}
