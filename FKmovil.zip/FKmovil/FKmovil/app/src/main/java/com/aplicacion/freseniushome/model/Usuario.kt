package com.aplicacion.freseniushome.model

data class Usuario(
    val id: Int? = null,
    val nombre: String = "",
    val email: String = ""
)

data class AuthResponse(
    val token: String,
    val user: Usuario
)

data class Producto(
    val id: Int,
    val name: String,
    val price_clp: Int,
    val imageUrl: String? = null,
    val stock: Int = 0
)

data class LoginRequest(
    val email: String,
    val password: String
)

data class RegisterRequest(
    val name: String,
    val email: String,
    val password: String
)
