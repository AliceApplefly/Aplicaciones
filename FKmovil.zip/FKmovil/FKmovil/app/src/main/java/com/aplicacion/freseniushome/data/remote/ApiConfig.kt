package com.aplicacion.freseniushome.data.remote

object ApiConfig {
    const val API_BASE = "https://x8ki-letl-twmt.n7.xano.io/api:302763/"
}
