package com.aplicacion.freseniushome.data.remote

import com.aplicacion.freseniushome.model.AuthResponse
import com.aplicacion.freseniushome.model.LoginRequest
import com.aplicacion.freseniushome.model.Producto
import com.aplicacion.freseniushome.model.RegisterRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface AuthService {
    @POST("auth/login")
    suspend fun login(@Body body: LoginRequest): Response<AuthResponse>

    @POST("auth/register")
    suspend fun register(@Body body: RegisterRequest): Response<AuthResponse>
}

interface ProductService {
    @GET("products")
    suspend fun listProducts(
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 12
    ): Response<List<Producto>>

    @GET("products/{id}")
    suspend fun getProduct(@Path("id") id: Int): Response<Producto>
}
