package com.aplicacion.freseniushome.data.remote

import com.google.gson.GsonBuilder
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {
    private val logging = HttpLoggingInterceptor().apply { 
        level = HttpLoggingInterceptor.Level.BODY 
    }

    @Volatile var tokenProvider: () -> String? = { null }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor { chain ->
            val token = tokenProvider()
            val request = if (!token.isNullOrBlank()) {
                chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer $token")
                    .build()
            } else {
                chain.request()
            }
            chain.proceed(request)
        }
        .addInterceptor(logging)
        .build()

    private fun retrofit(): Retrofit = Retrofit.Builder()
        .baseUrl(ApiConfig.API_BASE)
        .client(okHttpClient)
        .addConverterFactory(GsonConverterFactory.create(GsonBuilder().create()))
        .build()

    val auth: AuthService by lazy { retrofit().create(AuthService::class.java) }
    val products: ProductService by lazy { retrofit().create(ProductService::class.java) }
}
