pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS) // End of this statement
    repositories {                                             // This block starts on a new line
        google()
        mavenCentral()
    }
}
rootProject.name = "FKmovil"
include(":app")
